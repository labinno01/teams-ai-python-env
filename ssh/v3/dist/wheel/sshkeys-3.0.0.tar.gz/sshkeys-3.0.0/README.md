# sshkeys v3.0.0

Un outil en ligne de commande pour gérer les clés SSH, écrit en Python.

## Installation

Pour installer l'outil, exécutez la commande suivante à la racine du projet `ssh/v3` :

```bash
source ../../.venv/bin/activate
pip install -e .
```
